import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormArray, AbstractControl, Form } from '@angular/forms';
import { ProviderService } from '../provider.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-invoice',
  templateUrl: './create-invoice.component.html',
  styleUrls: ['./create-invoice.component.css']
})
export class CreateInvoiceComponent implements OnInit {
  invoiceForm: FormGroup;
  invoiceItems: FormArray;
  lstCustomer = [];
  lstItem = [];
  isAutoGenerate: boolean = false;  
  iAmount: number;
  typeOfDiscount: string = "dollar";
  localStorageArray: any = [];
  tempDiscount: number;
  shippingCharge: number;
  subTotal: number;
  finalTotal: number;
  itemPrice = [];
  amount = [];
  min: any;
  iNumber: number;
  invalidQuantity: boolean = false;
  itemsToSet = [];
  oNo: any;
  lstRecordsFromLocal: any = [];
  lstInvoiceItemsToEdit = [];
  invoiceEditable: boolean = false;
  removeLastElement: number = 1;
  constructor(private fb: FormBuilder, private provider: ProviderService, private route: ActivatedRoute) {

  }
  @ViewChild('discount') discountTemplate: ElementRef;
  @ViewChild('shipping') shippingTemplate: ElementRef;
  @ViewChild('chkAutoGenerate') chkAutoGenerate: ElementRef;
  @ViewChild('iNumber') iNumberTxt: ElementRef;

  ngOnInit() {

    this.oNo = this.route.snapshot.paramMap.get('no')

    if (!this.oNo) {

      // if there is no invoice to edit 
      if (localStorage.getItem('itemList')) {
        this.lstItem = JSON.parse(localStorage.getItem('itemList'))
      } else {
        this.lstItem = this.provider.getItemList();
      }
      if (localStorage.getItem('customerList')) {

        this.lstCustomer = JSON.parse(localStorage.getItem('customerList'))
      } else {
        this.lstCustomer = this.provider.getCustomerList();
      }
    } else {
      // If there is an invoice to edit then  

      this.lstRecordsFromLocal = [];
      this.lstRecordsFromLocal = JSON.parse(localStorage.getItem('createdInvoice'));

      for (let i = 0; i < this.lstRecordsFromLocal.length; i++) {
        if (this.lstRecordsFromLocal[i].orderNo == this.oNo) {
          this.lstInvoiceItemsToEdit.push(this.lstRecordsFromLocal[i]);
          this.invoiceEditable = true;
          this.iNumber = this.lstRecordsFromLocal[i].invoiceNo;


          break;
        } else {
          continue;
        }
      }
    }

    //Invoice is not editable
    if (this.invoiceEditable == false) {

      this.invoiceForm = this.fb.group({
        custName: [this.lstCustomer[0].name, Validators.required],
        invoiceNo: ['', Validators.compose([Validators.required, Validators.pattern('[0-9]\\d{5}')])],
        orderNo: ['', Validators.required],
        invoiceDate: ['', Validators.required],
        dueDate: ['', Validators.required],
        invoiceItems: this.fb.array([])
      })
    } else {
      // If Invoice is editable
      this.invoiceForm = this.fb.group({
        custName: [this.lstInvoiceItemsToEdit[0].custName, Validators.required],
        invoiceNo: [this.lstInvoiceItemsToEdit[0].invoiceNo, Validators.compose([Validators.required, Validators.pattern('[0-9]\\d{5}')])],
        orderNo: [this.lstInvoiceItemsToEdit[0].orderNo, Validators.required],
        invoiceDate: [this.lstInvoiceItemsToEdit[0].invoiceDate, Validators.required],
        dueDate: [this.lstInvoiceItemsToEdit[0].dueDate, Validators.required],
        invoiceItems: this.fb.array([])
      })
      this.discountTemplate.nativeElement.value = this.lstInvoiceItemsToEdit[0].discount;
      this.shippingTemplate.nativeElement.value = this.lstInvoiceItemsToEdit[0].shippingCharge;
      this.invoiceForm.setControl('invoiceItems', this.setInvoiceItems(this.lstInvoiceItemsToEdit[0].invoiceItems))
      this.removeLastElement = 2;
      this.addItem();
      this.calculateFinalTotal();
      // this.addItem();
    }

  }

  calculateFinalTotal() {
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    this.subTotal = 0;
    this.finalTotal = 0;


    for (let i = 0; i < form.length; i++) {
      this.subTotal += form.controls[i].get('itemAmount').value;
    }
    this.tempDiscount = this.lstInvoiceItemsToEdit[0].discount;
    this.shippingCharge = this.lstInvoiceItemsToEdit[0].shippingCharge
    this.finalTotal = this.subTotal
    this.finalTotal -= this.tempDiscount;
    this.finalTotal += Number(this.shippingCharge);
  }
  setInvoiceItems(iItems = []): FormArray {
    const formArray = new FormArray([]);
    iItems.forEach(s => {


      formArray.push(
        this.fb.group({
          itemName: s.itemName,
          itemQuantity: s.itemQuantity,
          itemRate: s.itemRate,
          itemAmount: s.itemAmount
        })
      )
    })
    return formArray;
  }
  addItem(): void {
    if (localStorage.getItem('itemList')) {
      this.lstItem = JSON.parse(localStorage.getItem('itemList'))
    } else {
      this.lstItem = this.provider.getItemList();
    }
    if (localStorage.getItem('customerList')) {

      this.lstCustomer = JSON.parse(localStorage.getItem('customerList'))
    } else {
      this.lstCustomer = this.provider.getCustomerList();
    }
    const creds = this.invoiceForm.controls.invoiceItems as FormArray;
    creds.push(this.fb.group({
      itemName: [this.lstItem[0].id, Validators.required],
      itemQuantity: [1, Validators.required],
      itemRate: [this.lstItem[0].amount, Validators.required],
      itemAmount: [this.lstItem[0].amount]
    }))
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    if (this.removeLastElement == 2) {
      creds.removeAt(form.length - 1);
      this.removeLastElement = 1;
      this.calculateFinalTotal();
    } else {

      this.subTotal = 0;
      this.finalTotal = 0;
      for (let i = 0; i < form.length; i++) {
        this.finalTotal += form.controls[i].get('itemAmount').value;
      }
      this.subTotal = this.finalTotal;
      this.discount = this.discountTemplate.nativeElement.value;
      this.shippingCharge = this.shippingTemplate.nativeElement.value;
      this.finalTotal -= Number(this.discount);
      this.finalTotal += Number(this.shippingCharge)
    }
  }

  generateInvoice() {
    if (this.invoiceForm.valid) {
      let iDate = this.invoiceForm.value.invoiceDate;
      let dDate = this.invoiceForm.value.dueDate;
      if (dDate < iDate) {
        alert("Due date can not be less than issued date")
      } else {
        var form = <FormArray>this.invoiceForm.get('invoiceItems');
        if (!form.length) {
          alert("Please select item")
        } else {
          if (localStorage.getItem('createdInvoice')) {
            this.localStorageArray = JSON.parse(localStorage.getItem('createdInvoice'));
            const data = this.invoiceForm.value;
            if (this.isAutoGenerate) {

              data.invoiceNo = this.min;
            }
            else {


              data.invoiceNo = this.iNumber;
            }

            data.amount = this.finalTotal
            data.discount = this.discountTemplate.nativeElement.value;
            data.shippingCharge = this.shippingCharge
            if (this.invoiceEditable) {

              for (let i = 0; i < this.localStorageArray.length; i++) {

                if (this.oNo == this.localStorageArray[i].orderNo) {

                  this.localStorageArray[i] = data;

                  break;
                }
                else {

                }
              }
              this.invoiceEditable = false;
            } else {

              this.localStorageArray.push(data);
            }

            localStorage.setItem('createdInvoice', JSON.stringify(this.localStorageArray))
            this.discountTemplate.nativeElement.value = ""
            this.shippingTemplate.nativeElement.value = ""
            this.subTotal = 0
            this.tempDiscount = 0;
            this.shippingCharge = 0;
            this.finalTotal = 0

          } else {

            this.localStorageArray = [];
            const data = this.invoiceForm.value;
            if (this.isAutoGenerate) {
              data.invoiceNo = this.min;
            }


            data.amount = this.finalTotal
            // data.discount = this.discount;
            data.discount = this.discountTemplate.nativeElement.value;
            data.shippingCharge = this.shippingCharge
            this.localStorageArray.push(data);

            localStorage.setItem('createdInvoice', JSON.stringify(this.localStorageArray));
            this.discountTemplate.nativeElement.value = ""
            this.shippingTemplate.nativeElement.value = ""
            this.subTotal = 0
            this.tempDiscount = 0;
            this.shippingCharge = 0;
            this.finalTotal = 0
          }
          this.invoiceForm.controls['invoiceNo'].enable();

          this.invoiceForm.reset();
          this.isAutoGenerate = false;
        }

      }
    } else {
      alert("Invalid form")
    }
  }

  autoGenerate(val) {

    this.isAutoGenerate = !this.isAutoGenerate;

    if (this.isAutoGenerate) {

      this.localStorageArray = JSON.parse(localStorage.getItem('createdInvoice'));
      if (this.localStorageArray) {

        try {
          this.min = Number(this.localStorageArray[0].invoiceNo);
          for (let i = 0; i < this.localStorageArray.length; i++) {
            if (this.localStorageArray[i].invoiceNo > this.min) {
              this.min = this.localStorageArray[i].invoiceNo;
            }
          }
          this.min = Number(this.min) + 1;

          let x = this.min.toString().length;
          if (x == 1) {
            this.min = '00000' + this.min;
          }

        } catch (error) {
        }

      } else {
        // alert("NO")
        this.min = '000001';

      }

      this.invoiceForm.patchValue({
        invoiceNo: this.min
      })
      this.invoiceForm.controls['invoiceNo'].disable();
    } else {

      this.invoiceForm.patchValue({
        invoiceNo: ""
      })
      this.invoiceForm.controls['invoiceNo'].enable();
    }
  }
  validateDate() {
    let iDate = this.invoiceForm.value.invoiceDate;
    let dDate = this.invoiceForm.value.dueDate;
    if (dDate < iDate) {
      alert("Due date can not be less than issued date")
    }

  }
  calAmount(i, val) {

    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    let l = form.controls[i].get('itemQuantity').value

    if (l <= 0) {
      alert("Invalid Quantity")
      form.controls[i].get('itemQuantity').setValue("");

    } else {
      this.invalidQuantity = false;
      form.controls[i].get('itemAmount').setValue(l * form.controls[i].get('itemRate').value)

      this.subTotal = 0;
      for (let i = 0; i < form.length; i++) {
        this.subTotal += form.controls[i].get('itemAmount').value
      } this.finalTotal = this.subTotal;
    }

  }
  callDiscount(val, discount) {


    if (!discount) {
      alert("Please enter discount")
    } else {
      this.typeOfDiscount = val;
      var form = <FormArray>this.invoiceForm.get('invoiceItems');

      if (this.typeOfDiscount == "dollar") {
        this.subTotal = 0
        for (let i = 0; i < form.length; i++) {
          this.subTotal += form.controls[i].get('itemAmount').value
        }
        this.finalTotal = this.subTotal;


        this.finalTotal = this.subTotal - discount;
        this.tempDiscount = discount;
      } else {
        this.subTotal = 0;
        for (let i = 0; i < form.length; i++) {
          this.subTotal += form.controls[i].get('itemAmount').value;
        }
        let x = (this.subTotal * discount) / 100;
        this.finalTotal = this.subTotal - x
        this.tempDiscount = x;

      }

    }



    //  else{
    //   this.subTotal=0;
    //   for(let i=0;i<form.length;i++){
    //     this.subTotal+=form.controls[i].get('itemAmount').value;
    //   }
    //   let x = (this.subTotal * val) / 100;
    //   this.finalTotal = this.subTotal-x
    //   console.log("x",x);


    // }


  }
  discount: number = 0;

  calculateDiscount(val, disType) {
     
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    if (!form.length) {

      // alert("Please add item first")
      this.discountTemplate.nativeElement.value = "";
      // this.discountTemplate.nativeElement.focus();

    } else {

      

      if (val.toString().length == 0) {
        alert("Invalid discount")
        this.discountTemplate.nativeElement.value = "";
        this.discountTemplate.nativeElement.blur();
        this.shippingTemplate.nativeElement.blur();
        this.tempDiscount = 0
        this.finalTotal = 0;
        for (let i = 0; i < form.length; i++) {
          this.finalTotal += form.controls[i].get('itemAmount').value
        }
      } else {
         this.finalTotal = 0;
        if (disType == "dollar") {
           this.subTotal = 0
          for (let i = 0; i < form.length; i++) {
            this.subTotal += form.controls[i].get('itemAmount').value
          }
           
          if(this.discountTemplate.nativeElement.value > this.subTotal ){
            this.tempDiscount = 0;
            this.discountTemplate.nativeElement.value=""
            this.finalTotal = this.subTotal;
            return;
          }else{

            this.tempDiscount = val;
          
          }
          this.finalTotal = this.subTotal - val;
          if (this.shippingCharge) {
            this.finalTotal += Number(this.shippingCharge);
          }
        } else {
          this.subTotal = 0;
          for (let i = 0; i < form.length; i++) {
            this.subTotal += form.controls[i].get('itemAmount').value;
          }
          let x = (this.subTotal * val) / 100;
          this.tempDiscount = x;
          this.finalTotal = this.subTotal - x
          if (this.shippingCharge) {
            this.finalTotal += Number(this.shippingCharge);
          }
        }
        // this.finalTotal -= this.tempDiscount;
      }
    }
  }
  calShippingCharge(val) {
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    if (!form.length) {
      // alert("Please add item first");
      this.shippingTemplate.nativeElement.value = ""
    } else {
      this.shippingCharge = 0;
      this.shippingCharge = Number(this.shippingTemplate.nativeElement.value)
      if (this.shippingCharge <= 0) {
        alert("Invalid shipping charge")
        this.discountTemplate.nativeElement.blur();
        this.shippingTemplate.nativeElement.blur();
      } else {
        this.shippingCharge = val;

        this.finalTotal += Number(val);
      }
    }
  }
  itemChanged(item, index) {
    //index is formArray index
    let x;
    const it = this.lstItem.find(x => x.id == item)
    var form = <FormArray>this.invoiceForm.get('invoiceItems');
    form.controls[index].get('itemRate').setValue(it.amount);
    form.controls[index].get('itemAmount').setValue(1 * it.amount)
    this.subTotal = 0
    for (let i = 0; i < form.length; i++) {
      this.subTotal += form.controls[i].get('itemAmount').value;
    }
    this.finalTotal = this.subTotal
  }
  storeInvoice(val) {


    localStorage.setItem("inNumber", JSON.stringify(val));
    let l = localStorage.getItem('inNumber');
    this.iNumber = val;
  }
}

