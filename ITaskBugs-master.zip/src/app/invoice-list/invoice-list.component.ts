import { Component, OnInit } from '@angular/core';
import { ProviderService } from '../provider.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-invoice-list',
  templateUrl: './invoice-list.component.html',
  styleUrls: ['./invoice-list.component.css']
})
export class InvoiceListComponent implements OnInit {

  constructor(private provider : ProviderService, private router : Router) { }
lstInvoice = [];
  ngOnInit() {

     try {
      
      this.lstInvoice = JSON.parse(localStorage.getItem('createdInvoice'));
    } catch (error) {
      
    }
    if(this.lstInvoice){
      for(let i=0; i<this.lstInvoice.length;i++){
        if(this.lstInvoice[i].invoiceNo == '00000'){
          this.lstInvoice[i].invoiceNo = '000001'
        }else{
           
        }
      }
    }
    else{
      alert("No records found!")
    }
  }
  editInvoice(item){
    console.log("ITEM ORDER",item.orderNo);
    
    // localStorage.setItem("editableInvoice",JSON.stringify(item));
        // this.router.navigateByUrl("createInvoice");
        this.router.navigate(['/createInvoice',{no : item.orderNo }])
  }

}
