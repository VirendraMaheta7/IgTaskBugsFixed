import { Component, OnInit, ViewChild } from '@angular/core';
import { ProviderService } from '../provider.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ModalDirective } from 'ngx-bootstrap';

@Component({
  selector: 'app-customer-list',
  templateUrl: './customer-list.component.html',
  styleUrls: ['./customer-list.component.css']
})
export class CustomerListComponent implements OnInit {
  addCustomerForm: FormGroup;
  lstCustomer = [];
  isEdit: boolean = false;
  custId: number;
  custExist : boolean = false;
  editCustExist : boolean = false;
  @ViewChild('customerModal') customerModal: ModalDirective;

  constructor(private provider: ProviderService, private fb: FormBuilder) {

  }

  ngOnInit() {
    if (!localStorage.getItem('customerList')) {
      
      this.lstCustomer = this.provider.getCustomerList();
    } else {
      this.lstCustomer = JSON.parse(localStorage.getItem('customerList'))
    }
    this.initCustomerForm();
  }
  initCustomerForm() {
    this.addCustomerForm = this.fb.group({
      cName: ['', Validators.required],
      cNumber: ['', Validators.compose([Validators.required, Validators.pattern('[0-9]\\d{9}')])],
      cAddress: ['', Validators.required]
    })
  }

  openCustomerModal() {
    this.customerModal.show();
  }
  submitCustomerForm() {
    if (this.addCustomerForm.valid) {
      if (this.isEdit == true) {
        alert();
        if(localStorage.getItem('customerList')){
          let umobile = Number(this.addCustomerForm.get('cNumber').value);
          this.lstCustomer = JSON.parse(localStorage.getItem('customerList'));

          for(let i=0;i<this.lstCustomer.length;i++){
            if(this.lstCustomer[i].id == i+1){
              this.lstCustomer[i].name = this.addCustomerForm.value.cName;
                  this.lstCustomer[i].mobile = this.addCustomerForm.value.cNumber;
                  this.lstCustomer[i].city = this.addCustomerForm.value.cAddress
                  localStorage.setItem('customerList', JSON.stringify(this.lstCustomer));
              this.addCustomerForm.reset();
              break;  
            }else{
                continue;
            }
          }
           this.isEdit=false; 

        }else{
          let umobile = Number(this.addCustomerForm.get('cNumber').value);
          for(let i=0;i<this.lstCustomer.length;i++){
            if(this.lstCustomer[i].mobile == umobile){
              this.lstCustomer[i].name = this.addCustomerForm.value.cName;
                  this.lstCustomer[i].mobile = this.addCustomerForm.value.cNumber;
                  this.lstCustomer[i].city = this.addCustomerForm.value.cAddress
                  localStorage.setItem('customerList', JSON.stringify(this.lstCustomer));
              this.addCustomerForm.reset();
              break;  
            }else{
                continue;
            }
          }
            

          
        }



        // for (let i = 0; i < this.lstCustomer.length; i++) {
        //   if (i == this.custId) {
        //     this.lstCustomer[i].name = this.addCustomerForm.value.cName;
        //     this.lstCustomer[i].mobile = this.addCustomerForm.value.cNumber;
        //     this.lstCustomer[i].city = this.addCustomerForm.value.cAddress
        //   }
        //   localStorage.setItem('customerList', JSON.stringify(this.lstCustomer))
        //   this.isEdit = false;
        // }
      }
      else {
          const data = {
          id: this.lstCustomer.length + 1,
          name: this.addCustomerForm.value.cName,
          mobile: this.addCustomerForm.value.cNumber,
          city: this.addCustomerForm.value.cAddress
        }
        if (localStorage.getItem('customerList')) {
          
            this.lstCustomer = JSON.parse(localStorage.getItem('customerList'));
           let userMobile = Number(this.addCustomerForm.get('cNumber').value)
           
            for(let i=0;i<this.lstCustomer.length;i++){
            if(this.lstCustomer[i].mobile == userMobile){
              alert("Customer already exists")
              this.addCustomerForm.reset();
              break;  
            }else{
              // alert("NOT MATCHED")
              // this.lstCustomer.splice(this.lstCustomer.length + 1, 0, data);
              // localStorage.setItem('customerList', JSON.stringify(this.lstCustomer));
              // break;
              continue;
            }
          }
          this.addCustomerForm.reset();
        } else {
           alert("NOPE")
          //   this.lstCustomer.splice(this.lstCustomer.length + 1, 0, data);
          //   localStorage.setItem('customerList', JSON.stringify(this.lstCustomer));
          let userMobile = Number(this.addCustomerForm.get('cNumber').value);
          for(let i=0;i<this.lstCustomer.length;i++){
            if(this.lstCustomer[i].mobile == userMobile){
              alert("Customer already exists")
              this.custExist = true;
              this.addCustomerForm.reset();
              break;  
            }else{
              // alert("NOT MATCHED")
              // this.lstCustomer.splice(this.lstCustomer.length + 1, 0, data);
              // localStorage.setItem('customerList', JSON.stringify(this.lstCustomer));
              // break;
              // continue;

              this.custExist=false;
            }
          }
          if(this.custExist){

          }else{
            this.lstCustomer.splice(this.lstCustomer.length + 1, 0, data);
            localStorage.setItem('customerList', JSON.stringify(this.lstCustomer)); 
          }
            this.addCustomerForm.reset();
        }

      }
      this.customerModal.hide();
    }
  }


  editCustomer(cust, id) {
    this.isEdit = true;
    this.custId = id;

    this.customerModal.show();
    this.addCustomerForm.patchValue({
      cName: cust.name,
      cNumber: cust.mobile,
      cAddress: cust.city
    })

  }
  deleteCustomer(i) {
    this.lstCustomer.splice(i, 1);
    localStorage.setItem('customerList', JSON.stringify(this.lstCustomer))
  }
  closeDeptModal() {
    this.customerModal.hide();
  }
}
