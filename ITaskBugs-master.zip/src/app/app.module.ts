import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InvoiceListComponent } from './invoice-list/invoice-list.component';
import { CreateInvoiceComponent } from './create-invoice/create-invoice.component';
import { ItemListComponent } from './item-list/item-list.component';
import { CustomerListComponent } from './customer-list/customer-list.component';
import { FormsModule, ReactiveFormsModule} from '@angular/forms'
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { ModalModule } from 'ngx-bootstrap';
 
@NgModule({
  declarations: [
    AppComponent,
    InvoiceListComponent,
    CreateInvoiceComponent,
    ItemListComponent,
    CustomerListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,RouterModule.forRoot([
      { path : 'invoiceList', component : InvoiceListComponent},
      { path : 'createInvoice', component : CreateInvoiceComponent},
      { path : 'itemList', component : ItemListComponent},
      { path : 'customerList', component : CustomerListComponent},
      { path : "" , component : CreateInvoiceComponent}
    ]),
    FormsModule, ReactiveFormsModule,
    OwlDateTimeModule, OwlNativeDateTimeModule,
    ModalModule.forRoot()
   ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
